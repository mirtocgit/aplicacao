/*Enconding=UTF-8*/
package netgest.bo.docHtml;
import java.io.CharArrayWriter;
import java.io.PrintWriter;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.net.URLDecoder;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Set;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.jsp.PageContext;

import net.sf.saxon.Controller;
import netgest.bo.boConfig;
import netgest.bo.def.boDefAttribute;
import netgest.bo.def.boDefHandler;
import netgest.bo.def.boDefMethod;
import netgest.bo.def.boDefViewer;
import netgest.bo.def.boDefViewerCategory;
import netgest.bo.def.boDefXeoCode;
import netgest.bo.impl.Ebo_TemplateImpl;
import netgest.bo.impl.templates.boTemplateManager;
import netgest.bo.localizations.LoggerMessageLocalizer;
import netgest.bo.localized.JSPMessages;
import netgest.bo.runtime.AttributeHandler;
import netgest.bo.runtime.EboContext;
import netgest.bo.runtime.ObjAttHandler;
import netgest.bo.runtime.boAttributesArray;
import netgest.bo.runtime.boConvertUtils;
import netgest.bo.runtime.boObject;
import netgest.bo.runtime.boObjectContainer;
import netgest.bo.runtime.boObjectList;
import netgest.bo.runtime.boRuntimeException;
import netgest.bo.runtime.boThread;
import netgest.bo.runtime.bridgeHandler;
import netgest.bo.security.securityRights;
import netgest.bo.system.Logger;
import netgest.bo.system.boPoolOwner;
import netgest.bo.utils.SchemaUtils;
import netgest.utils.ClassUtils;
import netgest.utils.ngtXMLHandler;

//Há pessoas que choram por saberem que as rosas têm espinhos; outras há que sorriem por saberem que os espinhos têm rosas.
//

public final class docHTML  extends boObjectContainer implements boPoolOwner {

    //logger
    private static Logger logger = Logger.getLogger("netgest.bo.dochtml.docHTML");

//   // GRANDE MARTELADA
//   private long p_lasttemplateobui=0;
//   private String p_lasttemplateobjectname="";
//   // GRANDE MARTELADA
//
   private StringBuffer     p_errors = new StringBuffer();



   private String           p_currentBoClsName;
   private String           p_currentBoListId;

   //private ParametersHandler p_initialparameters;

   private boObjectList     p_masterBoList;
   private String           p_masterBoClsName;
   private Hashtable        p_boLists;
   private int              p_id;
   //private docHTMLerrorHandler p_errorList=new docHTMLerrorHandler();
   private boDefHandler     p_masterBodef;
   private Hashtable        p_grids;
   private Hashtable        p_groupGrids;
   private Hashtable        p_sections;
   private static int counter =0;
   private Hashtable p_values;
   private boolean docTotalRefresh = false;
   private boolean parentRefresh = false;
   private ArrayList changedValues;
   private String p_poolUniqueId;
  
/*old version */


//   public String top="0";
//
//   public String left="0";
//   public String height="100%";
//   public String width="100%";

    /* SYSTEM PARAMETERS */
    private String      p_METHOD;
//  private byte        p_SCOPE;
    private long        p_BOUI;
    private long        p_PARENT_BOUI;
    private String      p_PARENT_ATTRIBUTE;

//    private int         p_PARENT_DOCID;
    private String      p_BOQL;
    private String      p_LIST_FROMMETHOD;
    private String      p_DROPINFO;
    private String      p_BOUISLIST;


    private String      p_OBJECT;
    private String      p_VALUES;
//    private byte        p_NEW_DOC;



//    public boolean ignoreClose = false;  // Flag ignore client request's for close.
//    public Vector  toClose = new Vector(); // doc's idx to close when this is close.


    private int         p_METH_LIST_PAGENUMBER;
    private int         p_METH_LIST_PAGESIZE;
    private String      p_METH_LIST_ORDERBY;
    private String      p_METH_LIST_FULLTEXT;
    private boolean     p_METH_LIST_ALIAS;
    private boolean     p_METH_LIST_WFIRST_ROWS;
    private String      p_METH_ALIAS_OBJ;
    private String      p_METH_LIST_USER_QUERY;
    private String[]    p_METH_LIST_LETTER;
    private boolean     p_METH_USE_SECURITY = true;
    
    //
    private boObject    p_MasterObject;

    private long p_OBJECT_TO_DUPLICATE = -1;
    private long p_FWD_BOUI = -1;
    private String p_TEMPLATE_DUPLICATE = null;

//   private String p_modeview=MODE_VIEW_NORMAL;

//   public static final String MODE_VIEW_EMBEBED="embebed";
//   public static final String MODE_VIEW_NORMAL="normal";

//   private byte state=0;
/*
   private int p_counter=0;
   private StringBuffer p_HTML_Name=new StringBuffer();
   private StringBuffer p_HTML_Id=new StringBuffer();

   private StringBuffer onSubmitForm=new StringBuffer();
   private StringBuffer onChangeForm=new StringBuffer();
   */
   private long p_activebo;
   private transient ArrayList undoableEditListeners = new ArrayList(2);
   //marca se está a correr em modo wizzard
   public boolean p_wizzard = false;
   public boolean p_WebForm = false;
   //private static Hashtable p_querysstore = new Hashtable();


   private boThread p_thread;

   // Para retirar
//   public docHTML_path p_path;
//   public ArrayList p_pathHistory = null;
//   public int p_pathHistoryPointer=-1;
   // end Para retirar

    //tipos utilizados para o tabIndex
    public static final byte FIELD=1;
    public static final byte GRID_CHECK_ALL=2;
    public static final byte BUTTON=3;
    public static final byte IFRAME=4;
    public static final byte AREA=5;
    public static final byte PANEL=6;
    public static final byte MENU=7;
    public static final byte SEARCH=8;
    public static final byte IMAGE=9;


   private Hashtable p_tabindex = new Hashtable();

   private Controller controller = null;
   private Hashtable controllerQueue = null;

   public docHTML(EboContext boctx, int docidx )
   {
       super(boctx);
       p_id = docidx;
//       p_DOCID = docidx;
       p_poolUniqueId =  "DOCHTML["+p_id+"]"+this.hashCode();

       p_boLists=new Hashtable();

       p_grids=new Hashtable();
       p_sections=new Hashtable();
       p_groupGrids=new Hashtable();
       counter++;
//       top="";//+counter*5;
//       left="";//+counter*5;
       p_values = new Hashtable();
       controllerQueue = new Hashtable();
   }

@Override
public void poolObjectPassivate() {
	
	
}

@Override
public void poolObjectActivate() {
	
	
}

}