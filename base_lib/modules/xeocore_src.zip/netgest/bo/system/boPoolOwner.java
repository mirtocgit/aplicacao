/*Enconding=UTF-8*/
package netgest.bo.system;
import netgest.bo.runtime.*;

/**
 * 
 * @author JMF
 */
public interface boPoolOwner 
{
    public boThread getThread();
}