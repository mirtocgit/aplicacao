/*Enconding=UTF-8*/
package netgest.bo.system;

/**
 * 
 * @Company Enlace3
 * @author João Paulo Trindade Carreira
 * @version 1.0
 * @since 
 */
public class boApplicationLogger 
{
    /**
     * 
     * @Company Enlace3
     * @since 
     */
    public boApplicationLogger( boApplication app )
    {
    }
}