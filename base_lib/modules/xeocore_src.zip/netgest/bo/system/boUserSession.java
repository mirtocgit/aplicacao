/*Enconding=UTF-8*/
package netgest.bo.system;
import java.util.Properties;
import netgest.bo.runtime.*;

/**
 * 
 * @Company Enlace3
 * @author João Paulo Trindade Carreira
 * @version 1.0
 * @since 
 */
public class boUserSession 
{
    private long boui;

    /**
     * 
     * @Company Enlace3
     * @since 
     */
    public boUserSession()
    {
    }

    public long getBoui()
    {
        return 0;
    }
    public boObject getEbo_Perf( EboContext ctx )
    {
        return null;
    }
    public String getRemoteMachineName()
    {
        return "";
    }
    public String getIpAddress()
    {
        return "";
    }
    public String getLoginName()
    {
        return "";
    }
    public long getLastActivityTime()
    {
        return 0;
    }
    public long getLogonTime()
    {
        return 0;
    }
    public int getNumberRequests()
    {
        return 0;
    }
    public Properties getProperties()
    {
        return null;   
    }
}