package netgest.bo.preferences;

public class XMLPreferenceStore {

}
