package netgest.bo.runtime.robots.ejbtimers.impl;

import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.ejb.TimedObject;
import javax.ejb.Timer;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import netgest.bo.localizations.LoggerMessageLocalizer;
import netgest.bo.runtime.robots.blogic.boSessionCleanAgentBussinessLogic;
import netgest.bo.runtime.robots.ejbtimers.XEOTimedObject;

import netgest.bo.runtime.robots.ejbtimers.XEOTimedObjectWrapper;
import netgest.bo.system.boLoginLocalHome;

import netgest.bo.system.Logger;

public class boSessionCleanAgentBean extends XEOTimedObjectWrapper implements SessionBean, TimedObject {
    private SessionContext _context;
    private static Logger logger = Logger.getLogger("netgest.bo.runtime.robots.ejbtimers.boSessionCleanAgent");
    
    public void ejbCreate()
    {
    }

    public void setSessionContext(SessionContext context)
        throws EJBException
    {
        _context = context;
    }

    public void ejbRemove()
        throws EJBException
    {
    }

    public void ejbActivate()
        throws EJBException
    {
    }

    public void ejbPassivate()
        throws EJBException
    {
    }

    public void start(String name) {
        super.start(name,_context);
    }
    
    public void suspend(String name) {
        super.suspend(name,_context);
    }

    public void scheduleNextRun(Timer timer) {
        super.scheduleNextRun(timer,_context);
    }  
     
    public void ejbTimeout(Timer timer)
    {
        XEOTimedObject timedObject=null;
        try
        {
            timedObject = super.getXEOTimedObject((String)timer.getInfo());
            if (timedObject!=null)
            {
                if(timedObject.isActive() && !timedObject.isRunning())
                {
                    timedObject.setIsRunning(true);
                    boSessionCleanAgentBussinessLogic logic = new boSessionCleanAgentBussinessLogic(timedObject.getXEOApplication());
                    logic.setInterval(timedObject.getInterval());
                    logic.execute();
                    scheduleNextRun(timer);
                    timedObject.setIsRunning(false);
                }
            }
            else logger.warn(LoggerMessageLocalizer.getMessage("XEOTIMEDOBJECT_NOT_FOUND"));
        }
        catch(Exception e)
        {
            logger.warn(LoggerMessageLocalizer.getMessage("UNEXPECTED_ERROR_EXECUTING_EJBTIMER")+" - "+(String)timer.getInfo());
            scheduleNextRun(timer);
            if (timedObject!=null)timedObject.setIsRunning(false);
        }
    }

    private boLoginLocalHome getboLoginLocalHome() throws NamingException {
        final InitialContext context = new InitialContext();
        return (boLoginLocalHome) context.lookup( "java:comp/env/ejb/local/boLogin" );
    }
}
