/*Enconding=UTF-8*/
package netgest.bo.runtime;

public interface boEventListener 
{
    public void onEvent( boEvent event );
}