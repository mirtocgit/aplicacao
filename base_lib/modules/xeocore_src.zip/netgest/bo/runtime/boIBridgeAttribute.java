/*Enconding=UTF-8*/
package netgest.bo.runtime;

/**
 * 
 * @Company Enlace3
 * @author João Paulo Trindade Carreira
 */
public interface boIBridgeAttribute 
{
    public    int  getLine();
    public    bridgeHandler getBridge();
}