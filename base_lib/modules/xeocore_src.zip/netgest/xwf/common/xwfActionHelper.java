/*Enconding=UTF-8*/
package netgest.xwf.common;

import java.io.ByteArrayOutputStream;
import java.io.CharArrayWriter;
import java.io.PrintStream;
import java.io.PrintWriter;

import java.lang.Boolean;
import java.util.ArrayList;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;


import netgest.bo.impl.Ebo_QueueImpl;
import netgest.bo.localizations.MessageLocalizer;

import netgest.bo.runtime.AttributeHandler;
import netgest.bo.runtime.EboContext;
import netgest.bo.runtime.boObject;
import netgest.bo.runtime.boObjectList;
import netgest.bo.runtime.boRuntimeException;
import netgest.bo.runtime.bridgeHandler;
import netgest.bo.system.boConnectionManager;

import netgest.bo.utils.DateUtils;
import netgest.utils.ClassUtils;

import netgest.utils.StringUtils;
import netgest.xwf.EngineGate;
import netgest.xwf.xwfEngineGate;
import netgest.xwf.core.xwfAnnounceImpl;
import netgest.xwf.core.xwfControlFlow;
import netgest.xwf.core.xwfECMAevaluator;
import netgest.xwf.core.xwfManager;
import netgest.xwf.core.xwfMessage;
import netgest.xwf.core.xwfStepExec;

import netgest.bo.system.Logger;

/**
 * <p>Title: xwfHelper </p>
 * <p>Description: Métodos comuns</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * @Company: Enlace3 </p>
 * @author Pedro Castro Campos
 * @version 1.0
 */
public final class xwfActionHelper 
{
    private static Logger logger = Logger.getLogger("netgest.xwf.common.xwfActionHelper");
   /**
     * Inicia um xwfProgram definido por um xwfStarterConfig.
     * @param ctx, EboContext contexto em que o programa é iniciado.
     * @param xwfStarterConfig, objecto de configuração onde está dinido o programa a ser executado.
     * @param object, boObjecto que deu origem ao programa 
     * @return result, TRUE caso tenha iniciado o programa, FALSE cc.
     */
    public static Hashtable OBJECTSSTARTCONFIG= new Hashtable();
    public static final String DUMMY =""; 
    
    public static void cleanCacheObjects()
    {
        OBJECTSSTARTCONFIG= new Hashtable();
    }
    public static boolean startProgram(EboContext ctx,long xwfStarterConfig, long object) throws boRuntimeException 
    {       
        boolean result = false;
        if(!xwfHelper.isInputVariableInProgram(boObject.getBoManager().loadObject(ctx,object)))
        {
            boObject starterConfig = null;
            if(xwfStarterConfig != -1 && object != -1)
            {              
                starterConfig = boObject.getBoManager().loadObject(ctx,xwfStarterConfig);
                long program = ClassUtils.convertToLong(starterConfig.getAttribute("program").getValueString(),-1);
                if(program != -1)
                {        
                    xwfManager manager = new xwfManager(ctx,null);
                    if(manager.createProgram(program,object,xwfHelper.PROGRAM_EXEC_DEFAULT_MODE) > 0)
                    {
                        result = true;   
                    }                
                }
            }
        }
        else
        {
            result = true;
        }
        return result;
    }  
    
    /**
     * Altera os previlégios de uma actividade de modo a que um participante possa ter acesso a mesma.
     * @param participant, boui do participante a dar previlégios.
     * @param activity, actividade sobre a qual p participante passa a ter previlégios.
     */     
    private static void givePrivileges(long participant, boObject activity)throws boRuntimeException
    {       
        
        boObject variable = null;            
        String activityName = activity.getName();
        if("xwfCreateReceivedMessage".equals(activityName) ||
           "xwfActivitySend".equals(activityName) ||
           "xwfActivityReceive".equals(activityName))
        {
            variable = activity.getAttribute("message").getObject();
            xwfStepExec.givePrivileges(participant,variable);
        }
        
        bridgeHandler bridge = activity.getBridge("variables");            
        bridge.beforeFirst();
        while(bridge.next())
        {
            variable = bridge.getObject();
            xwfStepExec.givePrivileges(participant,variable);
        }                    
    }
    /**
     * Dá previlégios a um programa de modo a que só os participante possam ter acesso.
     * @param activity, actividade em execução.
     */     
    public static void givePrivilegesToProgram(boObject activity, long programBoui)throws boRuntimeException
    {       
        boObject program = null;
        long assignedQueue = activity.getAttribute("assignedQueue").getValueLong();
        if(assignedQueue > 1 && programBoui > 1)
        {            
            program = boObject.getBoManager().loadObject(activity.getEboContext(),programBoui);
            if(program != null)
            {
                bridgeHandler bridge = program.getBridge("access");
                bridge.beforeFirst();
                if(!bridge.haveBoui(assignedQueue))
                {
                    bridge.add(assignedQueue);
                }
            }
        }
    }     
    /**
     * Reassigna uma xwfActivity, definida num xwfReassign.
     * @param activity, xwfActivity a reassignar.
     * @param object, xwfReassign objecto que contem a informação para a reassignação.
     */     
    public static  boolean reassignActivity(boObject activity, boObject object)  throws boRuntimeException
    {
        boolean result = false;        
        try
        {
            long reassigned = object.getAttribute("reassigned").getValueLong();
            if(reassigned < 1)
            {
                activity.getStateAttribute("runningState").setValueString("create");
                activity.getAttribute("performer").setValueString("");
                activity.getAttribute("beginDate").setValueString("");
                long to = object.getAttribute("to").getValueLong();
                activity.getAttribute("assignedQueue").setValueLong(to);
                givePrivileges(to,activity);
                
                object.getAttribute("errormessage").setValueString("");
                object.getAttribute("reassigned").setValueString("1");

                bridgeHandler bridge =  activity.getBridge("reassigns");
                bridge.beforeFirst();
                if(!bridge.haveBoui(object.getBoui()))
                {
                    bridge.add(object.getBoui());
                }                
//                getProxyManager().getBoManager().updateObject(activity);                
            }
            result = true;
        }
        catch (boRuntimeException ex) 
        {       
            try
            {
                if(object != null)
                {
                    CharArrayWriter cw = new CharArrayWriter();
                    PrintWriter pw = new PrintWriter( cw );
                    ex.printStackTrace( pw );
                    pw.close();
                    cw.close();                            
                    object.getAttribute("errormessage").setValueString(cw.toString());
                    object.getAttribute("reassigned").setValueString("-1");
                }
            }
            catch (Exception e)
            {
                
            }
        }               
        catch (Throwable ex) 
        {       
            try
            {
                CharArrayWriter cw = new CharArrayWriter();
                PrintWriter pw = new PrintWriter( cw );
                ex.printStackTrace( pw );
                pw.close();
                cw.close();                            
                object.getAttribute("errormessage").setValueString(cw.toString());
                object.getAttribute("reassigned").setValueString("-1");
            }
            catch (Exception e)
            {
                
            }
        }      
        return result;
    }    

//    public static boolean deliverMsessage(XwfController controller) throws boRuntimeException
//    {
//        return xwfMessage.deliverMessage(controller);
//    }
    public static boolean mergeMessage(EngineGate engine,boObject activity) throws boRuntimeException
    {
        return xwfMessage.mergeMessage(engine,activity);
    }  
    public static boObject replyMessage(EngineGate engine, boObject activity, boolean replyAll, String type) throws boRuntimeException
    {
        boObject newActivity = null;
        return newActivity;
    }
    public static boObject forwardMessage(EngineGate engine, boObject activity, String msgType) throws boRuntimeException
    {
        boObject newActivity = null;
        boObject variable = activity.getAttribute("message").getObject();
        boObject value = variable.getAttribute("value").getObject();
        boObject message = value.getAttribute(xwfHelper.VALUE_OBJECT).getObject();
        boObject forwardMessage = null;
        if(message != null)
        {
            if(msgType == null) msgType = message.getName();


            //TODO:Implement Interface LUSITANIA
            //forwardMessage = MessageServer.getForwardMessage(engine.getBoManager().getContext(), message, msgType);
            
            newActivity = ((xwfEngineGate)engine).getManager().createMessageActivity("xwfActivitySend", "FWD: " + message.getAttribute("name").getValueString(), forwardMessage, msgType);
            newActivity.getAttribute("branch").setValueString(activity.getAttribute("sid").getValueString());
        }
        
        return newActivity;
    }
    public static boObject sendMessage(EngineGate engine) throws boRuntimeException
    {
        return ((xwfEngineGate)engine).getManager().createMessageActivity("xwfActivitySend", "Nova mensagem", null, "message");
    } 
    public static void setRead(boObject activity, long performer) throws boRuntimeException
    {
        
    }    
    public static boolean moveProgram(EngineGate engine, boObject fromProgram,boObject toProgram) throws boRuntimeException
    {
        boolean result = false;
        return result;
    }
    public static boolean moveActivity(EngineGate engine, boObject fromProgram,boObject toProgram,boObject activity) throws boRuntimeException
    {
        boolean result = false;
        return result;
    }
   /* 
    public static boolean AremoveProgram(xwfBoManager manager, long programRuntimeBoui) throws boRuntimeException
    {   
        boolean result = false;
        boObject program = manager.getObject(programRuntimeBoui) ;
        boConnectionManager connManager = program.getEboContext().getConnectionManager();
        try 
        {

            connManager.beginOnlyDatabaseTransaction();

            removeParticipants(manager,programRuntimeBoui);        
            removeActivitys(manager,programRuntimeBoui);
            removeVariables(manager,programRuntimeBoui);                                
            removeWaits(manager,programRuntimeBoui);                
            removeSerialObjects(manager,programRuntimeBoui);
            manager.destroyObject(program);
            result = true;
        } 
        catch(boRuntimeException e) 
        {
            result = false;
        }
        finally 
        {
            if(result)
            {     
                result = connManager.commitOnlyDatabaseTransaction();
            }
            else
            {
                connManager.rollbackOnlyDatabaseTransaction();
            }
        }
        return result;
    }
    
    public static boolean removeProgram(xwfBoManager manager, long programRuntimeBoui) throws boRuntimeException
    {
        return removeProgram( manager, programRuntimeBoui, true);
    }
    public static boolean removeProgram(xwfBoManager manager, long programRuntimeBoui, boolean removeMessages) throws boRuntimeException
    {   
        boolean result = false;
        boObject program = manager.getObject(programRuntimeBoui) ;
//        boConnectionManager connManager = program.getEboContext().getConnectionManager();
//        try 
//        {

//            connManager.beginOnlyDatabaseTransaction();
            
            boObjectList activitys = manager.listObject("SELECT xwfActivity WHERE program = " + programRuntimeBoui,false,false);
            activitys.beforeFirst();
            ArrayList objectsToDestroy = new ArrayList();
            while ( activitys.next() )
            {
                objectsToDestroy.add( activitys.getObject() );
            }
            bridgeHandler bridgeParticipants = program.getBridge("participants");
            bridgeParticipants.beforeFirst();
            while ( bridgeParticipants.next() )
            {
                objectsToDestroy.add( bridgeParticipants.getObject() );
            }
            
            bridgeHandler bridgeVariables = program.getBridge("variables");
            bridgeVariables.beforeFirst();
            while ( bridgeVariables.next() )
            {
                boObject v = bridgeVariables.getObject();
                objectsToDestroy.add( v );
                boObject vv = v.getAttribute("value").getObject();
                if ( vv!= null )
                {
                    objectsToDestroy.add( vv );
                }
            }
            
            boObjectList list = manager.listObject("SELECT xwfWait WHERE program = " + programRuntimeBoui,false,false);
            list.beforeFirst();
            while(list.next())
            {
                objectsToDestroy.add( list.getObject() );
            }
            
//            list = manager.listObject("SELECT xwfSerialObject WHERE program = " + programRuntimeBoui,false,false);
//            list.beforeFirst();
//            while(list.next())
//            {
//                objectsToDestroy.add( list.getObject() );
//            }
//            
            
            bridgeHandler bridgeMessage = program.getBridge("message");
            bridgeMessage.beforeFirst();
            ArrayList messages = new ArrayList();
            while ( bridgeMessage.next() )
            {
                boObject v = bridgeMessage.getObject();
                messages.add( v );
            }
            bridgeHandler bridgeReadList =  program.getBridge("READLIST");
            if(bridgeReadList != null)
            {
                bridgeReadList.truncate();
            }
            program.destroyForce();
            
            for (int i = 0; i < objectsToDestroy.size(); i++) 
            {
                ( (boObject) objectsToDestroy.get(i)).destroyForce();
            }
            
            if( removeMessages )
            {
                List binary = null;
                boObject document = null;
                for (int i = 0; i < messages.size(); i++) 
                {
                    boObject msgO = ( (boObject) messages.get(i)); 
                    list = manager.listObject("SELECT xwfActivity ext WHERE message.value.valueObject = " + msgO.getBoui(), false,false );
                    if(list.getRowCount() == 0)
                    {
                        binary = msgO.getObjectBinary().getBinary();
                        bridgeHandler anexos = msgO.getBridge("documents");
                        anexos.beforeFirst();
                        List anexosToDestroy = new ArrayList();
                        while(anexos.next())
                        {
                            anexosToDestroy.add(anexos.getObject());
                        }                                                
                        msgO.destroyForce();
                        if(!msgO.exists() && binary != null)
                        {
                            for (int d = 0; d < binary.size(); d++) 
                            {
                                document = (boObject)binary.get(d);
                                if(document.getAttribute("fileName").getValueString().endsWith(".eml"))
                                {
                                    logger.finest("Destroy EML");
                                    document.destroy();                                    
                                }
                            }
                            Object creator = null;
                            for (int d = 0; d < anexosToDestroy.size(); d++) 
                            {                                
                                document = (boObject)anexosToDestroy.get(d);
                                creator = document.getAttribute("CREATOR").getValueObject();
                                if(creator == null)
                                {
                                    logger.finest("Destroy Anexo");
                                    document.destroy();                                    
                                }
                                
                            }                            
                        }                                                   
                    }
                }                
            }
            //removeParticipants(manager,programRuntimeBoui);        
            //removeActivitys(manager,programRuntimeBoui);
            //removeVariables(manager,programRuntimeBoui);                                
            //removeWaits(manager,programRuntimeBoui);                
            //removeSerialObjects(manager,programRuntimeBoui);
            
            result = true;
//        } 
//        catch(boRuntimeException e) 
//        {
//            result = false;
//        }
//        finally 
//        {
//            if(result)
//            {     
//                result = connManager.commitOnlyDatabaseTransaction();
//            }
//            else
//            {
//                connManager.rollbackOnlyDatabaseTransaction();
//            }
//        }
        return result;
    }
    

    public static boolean NremoveProgram(xwfBoManager manager, long programRuntimeBoui) throws boRuntimeException
    {   
        boolean result = false;
        boObject program = manager.getObject(programRuntimeBoui) ;
        program.destroyForce();
        
//            removeParticipants(manager,programRuntimeBoui);        
//            removeActivitys(manager,programRuntimeBoui);
//            removeVariables(manager,programRuntimeBoui);                                
//            removeWaits(manager,programRuntimeBoui);                
//            removeSerialObjects(manager,programRuntimeBoui);
//            manager.destroyObject(program);
        return true;
    }
    
    public static void removeActivity(xwfBoManager manager, long activityBoui) throws boRuntimeException
    {
        List values = new ArrayList();
        bridgeHandler bridge = null;
        boObject activity = null;
        boObject variable = null;
        boObject value = null;
        long boui = 0;
                
            activity = manager.getObject(activityBoui);      
            if(activity.getAttribute("message") != null)
            {
                variable = activity.getAttribute("message").getObject();  
                if(variable != null)
                {
                    boui = variable.getAttribute("value").getValueLong();
                    if(boui > 0)
                    {
                        values.add(String.valueOf(boui));
                    }           
                    values.add(String.valueOf(variable.getBoui()));
                }                
            } 
            if("xwfWaitResponse".equals(activity.getName())) // activity.getAttribute("saveOn") != null)
            {
                variable = activity.getAttribute("saveOn").getObject();
                if(variable != null)
                {
//                    activity.getAttribute("sendActivity").setValueObject(null);
//                    activity.getAttribute("saveOn").setValueObject(null);    
//                    activity.getAttribute("waitFrom").setValueObject(null);
//                    activity.getAttribute("receiveActivity").setValueObject(null);
//                    manager.updateObject(activity);
                    boui = variable.getAttribute("value").getValueLong();
                    if(boui > 0)
                    {
                        values.add(String.valueOf(boui));
                    }                   
                    values.add(String.valueOf(variable.getBoui()));
//                    manager.destroyObject(variable);                                    
                }
            }
//            else if("xwfActivityReceive".equals(activity.getName()))
//            {
//                activity.getAttribute("waitingResponse").setValueObject(null);
//                activity.getAttribute("relatedProgram").setValueObject(null);
//                manager.updateObject(activity);
//            }
            else if("xwfActivityChoice".equals(activity.getName()))
            {
                bridge  = activity.getBridge("options"); 
                bridge.beforeFirst();
                while(bridge.next())
                {
                    values.add(String.valueOf(bridge.getObject().getBoui()));
                }                
//                bridge.truncate();
//                manager.updateObject(activity);
            }
            else if("xwfActivityDecision".equals(activity.getName()))
            {
                boui = activity.getAttribute("no").getValueLong();
                if(boui > 0)
                {
                    values.add(String.valueOf(boui));
//                    activity.getAttribute("no").setValueObject(null);
                }
                boui = activity.getAttribute("yes").getValueLong();
                if(boui > 0)
                {
                    values.add(String.valueOf(boui));
//                    activity.getAttribute("yes").setValueObject(null);
                }                                            
//                manager.updateObject(activity);
            }            
            bridge = activity.getBridge("variables");
            bridge.beforeFirst();
            while(bridge.next())
            {
                variable = bridge.getObject();
                boui = variable.getAttribute("value").getValueLong();
                if(boui > 0)
                {
                    values.add(String.valueOf(boui));
//                    variable.getAttribute("value").setValueObject(null);                    
//                    manager.updateObject(variable);                                        
                }
                values.add(String.valueOf(variable.getBoui())); 
//                  manager.destroyObject(variable);                
            }
//            bridge.truncate();   
//            manager.updateObject(activity);
            xwfAnnounceImpl.removeAnnouncer(activity);
//            try
//            {
//                manager.destroyObject(activity);
//                activity.destroyForce();
//            }            
//            catch (boRuntimeException e)
//            {
                values.add(String.valueOf(activity.getBoui()));
//            }
        
        List binary = null;
        for (int i = 0; i < values.size(); i++) 
        {            
            value = manager.getObject(Long.parseLong((String)values.get(i)));
//            if(value.getAttribute(xwfHelper.VALUE_OBJECT) != null)
//            {
//               value.getAttribute(xwfHelper.VALUE_OBJECT).setValueObject(null);
//               value.getBridge(xwfHelper.VALUE_LIST).truncate();
//               manager.updateObject(value);
//            }
            try 
            {
                if("message".equals(value.getName()) || "message".equals(value.getBoDefinition().getBoSuperBo()))
                {
                    binary = value.getObjectBinary().getBinary();
                }
                value.destroyForce(); 
                if(!value.exists() && binary != null)
                {
                    boObject document = null;
                    for (int d = 0; d < binary.size(); d++) 
                    {
                        document = (boObject)binary.get(d);
                        if(document.getAttribute("fileName").getValueString().toLowerCase().endsWith(".eml"))
                        {
                            document.destroy();                                    
                        }
                    }
                }                
            } 
            catch (Exception ex) 
            {     
                //ignore another connection to this object, will be destroy in removeVariables
            }             
        }
                
    }
    
    private static void removeActivitys(xwfBoManager manager, long programRuntimeBoui) throws boRuntimeException
    {
        List values = new ArrayList();
        bridgeHandler bridge = null;
        boObject activity = null;
        boObject variable = null;
        boObject value = null;    
        long boui = 0;
        boObjectList activitys = manager.listObject("SELECT xwfActivity WHERE program = " + programRuntimeBoui,false,false);
        activitys.beforeFirst();
        while(activitys.next())
        {        
            xwfActionHelper.removeActivity(manager, activitys.getCurrentBoui());           
        }
                
    }
    private static void removeVariables(xwfBoManager manager, long programRuntimeBoui) throws boRuntimeException
    {
//        Hashtable values = new Hashtable();
        List values = new ArrayList();
        String key = null;
        boObject object = null;
        boObject parent = null;
        boObject program = manager.getObject(programRuntimeBoui);
         bridgeHandler variables = program.getBridge("variables");
        variables.beforeFirst();
        while(variables.next())
        {
            object = variables.getObject();
            key = object.getAttribute("value").getValueString();
            if(key != null && !"".equals(key))
            {
//                values.put(key,String.valueOf(object.getBoui()));
                values.add(key);
                object.getAttribute("value").setValueObject(null);
                manager.updateObject(object);                            
            }   
            values.add(String.valueOf(object.getBoui()));            
//            manager.destroyObject(object);
        }
        variables.truncate();
        manager.updateObject(program);
//        Enumeration keys = values.keys();
//        while(keys.hasMoreElements()) 
//        {      
        for (int i = 0; i < values.size(); i++) 
        {         
//            key = (String)keys.nextElement();
//            object = manager.getObject(Long.parseLong(key));
            object = manager.getObject(Long.parseLong((String)values.get(i)));            
            if(object.getAttribute(xwfHelper.VALUE_OBJECT) != null)
            {            
                object.getAttribute(xwfHelper.VALUE_OBJECT).setValueObject(null);
                object.getBridge(xwfHelper.VALUE_LIST).truncate();
                manager.updateObject(object);
            }
            manager.destroyObject(object);                            
        }        
    }    
    
    private static void removeParticipants(xwfBoManager manager, long programRuntimeBoui) throws boRuntimeException
    {
        List values = new ArrayList();
        boObject object = null;
        long boui = 0;
        boObject program = manager.getObject(programRuntimeBoui);
        bridgeHandler participants = program.getBridge("participants");
        participants.beforeFirst();
        while(participants.next())
        {
            object = participants.getObject();
            boui = object.getAttribute("value").getValueLong();
            if(boui > 0)
            {
                values.add(String.valueOf(boui));
                object.getAttribute("value").setValueObject(null);
                manager.updateObject(object);                
            }
            values.add(String.valueOf(object.getBoui()));
//            manager.destroyObject(object);
        }
        participants.truncate();
        manager.updateObject(program);
        for (int i = 0; i < values.size(); i++) 
        {            
            object = manager.getObject(Long.parseLong((String)values.get(i)));
            if(object.getAttribute(xwfHelper.VALUE_OBJECT) != null)
            {
               object.getAttribute(xwfHelper.VALUE_OBJECT).setValueObject(null);
               object.getBridge(xwfHelper.VALUE_LIST).truncate();
               manager.updateObject(object);
            }
            try 
            {
                manager.destroyObject(object);  
            } 
            catch (Exception ex) 
            {     
                //ignore another connection to this object, will be destroy in removeVariables
            }                
        }          
    }        
    private static void removeWaits(xwfBoManager manager, long programRuntimeBoui) throws boRuntimeException
    {
        boObject object = null;
        boObjectList list = manager.listObject("SELECT xwfWait WHERE program = " + programRuntimeBoui,false,false);
        list.beforeFirst();
        while(list.next())
        {
            object = list.getObject();
            manager.destroyObject(object);
        }
    }       
    private static void removeSerialObjects(xwfBoManager manager, long programRuntimeBoui) throws boRuntimeException
    {
        boObject object = null;
        boObjectList list = manager.listObject("SELECT xwfSerialObject WHERE program = " + programRuntimeBoui,false,false);
        list.beforeFirst();
        while(list.next())
        {
            object = list.getObject();            
            manager.destroyObject(object);
        }
    }       
    */
    public static void errorHandle(xwfBoManager xm, boObject notify_user, Exception e)
    {
      
    }
    
    public static boolean interruptProgram(String status, xwfBoManager xbm, xwfControlFlow xcf)throws boRuntimeException
    {
      try{
        xbm.getProgram().getStateAttribute("runningState").setValueString(status);
        String prog_boui_s = Long.toString(xbm.getProgBoui());
        String cancel_boql = "select xwfActivity STATE open or create where program = "+prog_boui_s;
        xcf.interruptActivity(status, cancel_boql, true);
        boObjectList bol = xbm.listObject("select xwfWait where program = "+prog_boui_s+" and done='0'", false);
        bol.beforeFirst();
        while(bol.next())
        {
          bol.getObject().destroy();
        }
        
        xbm.updateObject(xbm.getProgram());
        return true;
      }catch(Exception e){ return false; }
    }
    /**
     * Cria um fluxo de trabalho com base num tipo de boObject.
     * @param EngineGate, ligação core do workflow.
     * @param activityName, nome do boObject a criar um fluxo de trabalho.
     * @return activity, actividade gerada no ambito do fluxo de trabalho.
     */        
    public static boObject createEmbeddedProgram(EngineGate engine,String activityName) throws boRuntimeException
    {
        return null;
    }
    /**
     * Cria um fluxo de trabalho com base num tipo de boObject.
     * @param EngineGate, ligação core do workflow.
     * @param activityName, nome do boObject a criar um fluxo de trabalho.
     * @param message, boObject a incluir na actividade
     * @return activity, actividade gerada no ambito do fluxo de trabalho.
     */    
    public static boObject createEmbeddedProgram(EngineGate engine,String activityName,boObject message) throws boRuntimeException
    {
        String label = xwfFunctions.getIntelligentLabelEmbeddedProgram(engine,activityName,message.getName());
        boObject program = engine.getBoManager().createObject("xwfProgramRuntime");
        program.getAttribute("labelFormula").setValueString("message.name");
        program.getAttribute("beginDate").setValueDate(new Date());
        engine.getBoManager().setProgram(program.getBoui());       
        engine.getBoManager().updateObject(program);
        return ((xwfEngineGate)engine).getManager().createMessageActivity(activityName,label,message, message.getName());
    }    
    /**
     * Cria um Ebo_Queue para para iniciar um program xwf para este boObject.     
     * @param starterConfig, xwfStarterConfig configurado para este boObject.
     * @param object, objecto de input para o fluxo de trabalho.
     */
    private static void queueStartProgram(boObject starterConfig, boObject object) throws boRuntimeException 
    {           
        boObject queue = boObject.getBoManager().createObject(starterConfig.getEboContext(),"Ebo_Queue");
        queue.getAttribute("toperf").setValueLong(starterConfig.getEboContext().getBoSession().getPerformerBoui());
        String code = "xwfActionHelper.startProgram(ctx," + starterConfig.getBoui() + "," + object.getBoui() + ");";
        ((Ebo_QueueImpl)queue).addImportClass("netgest.xwf.common.xwfActionHelper");
        ((Ebo_QueueImpl)queue).setContextVarName("ctx");
        ((Ebo_QueueImpl)queue).addCode(code,Ebo_QueueImpl.JAVA_CODE);                
        queue.update();                   
    }  
    /**
     * Cria um Ebo_Queue para para iniciar um program xwf para este boObject caso seja automático.
     * @param object, objecto de input para o fluxo de trabalho.
     */
    public static void autoQueueStartProgram(boObject object) throws boRuntimeException 
    {           
    	//TODO:MYSQL
//        boObject starterConfig = getStarterConfig(object);
//        if(starterConfig != null && "1".equals(starterConfig.getAttribute("automatic").getValueString()))
//        {
//            queueStartProgram(starterConfig,object);
//        }            
    }    
    /**
     * Cria um Ebo_Queue para para iniciar um program xwf para este boObject caso seja manual.
     * @param object, objecto de input para o fluxo de trabalho.
     */
    public static void manualQueueStartProgram(boObject object) throws boRuntimeException 
    {           
        boObject starterConfig = getStarterConfig(object);
        if(starterConfig != null && "0".equals(starterConfig.getAttribute("automatic").getValueString()))
        {
            queueStartProgram(starterConfig,object);        
        }            
    }      
    /**
     * Devolve um xwfStarterConfig caso exista para este boObject.
     * @param object, objecto de origem do fluxo.
     * @return xwfStarterConfig,  xwfStarterConfig caso exista , null caso contrário.  
     */
    private static boObject getStarterConfig(boObject object) throws boRuntimeException 
    {
        
        String haveStarterConfig  =  (String) OBJECTSSTARTCONFIG.get(object.getName() );
        boObject result = null;
        if ( haveStarterConfig == null )
        {
            StringBuffer sb = new StringBuffer("SELECT xwfStarterConfig WHERE ");
            sb.append(" object in (").append("SELECT Ebo_ClsReg WHERE name='").append(object.getName()).append("')");
            sb.append(" AND ( beginDate IS NULL");
            sb.append(" OR TO_DATE(TO_CHAR(beginDate,'DD-MM-YYYY HH:MI'),'DD-MM-YYYY HH:MI') < TO_DATE(TO_CHAR(SYSDATE,'DD-MM-YYYY HH:MI'),'DD-MM-YYYY HH:MI'))");
            sb.append(" AND ( endDate IS NULL");
            sb.append(" OR TO_DATE(TO_CHAR(endDate,'DD-MM-YYYY HH:MI'),'DD-MM-YYYY HH:MI') > TO_DATE(TO_CHAR(SYSDATE,'DD-MM-YYYY HH:MI'),'DD-MM-YYYY HH:MI'))");
            boObjectList starterConfigList = boObjectList.list(object.getEboContext(), sb.toString() );
            if(starterConfigList.getRecordCount() > 0)
            {
                
                xwfBoManager manager = new xwfBoManager(object.getEboContext(),null);
                boolean found = false;
                starterConfigList.beforeFirst();            
                Object val = null;
                boObject program = null;
                xwfECMAevaluator eval = null;                
                while(starterConfigList.next() && !found)
                {             
                    program = starterConfigList.getObject();
                    String xep = program.getAttribute("condition").getValueString();
                    if(xep != null && !"".equals(xep.trim()))
                    {                
                        eval = new xwfECMAevaluator();
                        eval.setVariable("Objecto",boObject.class,object, object.getName());
                        val = eval.eval(manager,xep);
                        if(val != null && val instanceof Boolean)
                        {
                            if(((Boolean)val).booleanValue() == true)
                            {
                                found = true;
                                result = starterConfigList.getObject();       
                            }
                        }                    
                    }
                    else
                    {
                        found = true;
                        result = starterConfigList.getObject();
                    }                
                }                
            }
            else
            {
                OBJECTSSTARTCONFIG.put(object.getName(), DUMMY );
            }
            
        }
        return result;
    }
    public static boolean sendReadReceipt(EngineGate engine, boObject activity, boObject performer) throws boRuntimeException
    {
        return false;
    }
    
    public static boObject sendDeliverReceipt(EngineGate engine, boObject receiptMessage, boObject performer) throws boRuntimeException
    {
        boObject newActivity = null;             
        return newActivity;
    }
    
  
  /**
   * Altera o estado da actividade para reaberto, se o programa estiver fechado reabre este.
   * @param manager, xwfBoManager controlador de objectos no contexto do xwf.
   * @param program, fluxo de trabalho em execução.
   * @param activity, actividade a alterar o estado.    
   */      
    public static void reopenActivity(xwfBoManager manager,boObject program, boObject activity) throws boRuntimeException    
    {    
        if("close".equals(activity.getStateAttribute("runningState").getValueString()))
        {       
            if("close".equals(activity.getStateAttribute("runningState").getValueString()))
            {
                reopenProgram(manager,program);
            }
            activity.getStateAttribute("runningState").setValue("reopen");
            activity.getAttribute("endDate").setValueString(null);
            activity.getAttribute("unique_sid").setValueString("-1");            
            xwfHelper.objectStateSet(manager, "0");
        }            
    }
    public static void reopenProgram(xwfBoManager manager,boObject program) throws boRuntimeException
    {
        program.getStateAttribute("runningState").setValue("reopen");
        Date init = program.getAttribute("beginDate").getValueDate();
        if(init == null)
        {
            program.getAttribute("beginDate").setValueDate(new Date());
        }
        program.getAttribute("endDate").setValueDate(null);
    }     
    public static void openProgram(xwfBoManager xwfm, boObject program) throws boRuntimeException
    {
        program.getStateAttribute("runningState").setValue("open");
        Date init = program.getAttribute("beginDate").getValueDate();
        if(init == null)
        {
            program.getAttribute("beginDate").setValueDate(new Date());
        }
        program.getAttribute("endDate").setValueDate(null);
        xwfHelper.objectStateSet(xwfm, "0");
    }    
    
    public static boolean moveActivitiesToProgram(EngineGate engine, boObject originProg, boObject destinationProg, String activitiesToMove, String activitiesToDel) throws boRuntimeException
    {
        if(activitiesToMove != null)
        {
            String[] moveActivitiesBouis = activitiesToMove.split(",");
            for(int i=0; i<moveActivitiesBouis.length; i++)
            {
                boObject selectedActivity = originProg.getObject(Long.parseLong(moveActivitiesBouis[i]));
                if(moveActivity(engine, originProg, destinationProg, selectedActivity))
                {
                    engine.getBoManager().updateObject(selectedActivity);
                }
            }
        }
        return true;
    }
    
    /**
     * Transfere um fluxo para um outro grupo/pool/utilizador. Cancela o fluxo actual e 
     * associa o program a um novo grupo/utilizador
     * @param activity, xwfActivity a reassignar.
     * @param object, xwfActivityTransfer objecto que contem a informação para a transferência.
     */     
    public static  boolean transferProcess(boObject object)  throws boRuntimeException
    {
        boolean result = false;        
        return result;
    }
 
}