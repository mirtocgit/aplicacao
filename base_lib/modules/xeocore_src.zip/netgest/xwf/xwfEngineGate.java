/*Enconding=UTF-8*/
package netgest.xwf;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import netgest.bo.localizations.MessageLocalizer;
import netgest.bo.runtime.EboContext;
import netgest.bo.runtime.boObject;
import netgest.bo.runtime.boObjectList;
import netgest.bo.runtime.boRuntimeException;
import netgest.utils.ClassUtils;
import netgest.xwf.common.xwfActionHelper;
import netgest.xwf.common.xwfBoManager;
import netgest.xwf.common.xwfFunctions;
import netgest.xwf.common.xwfHelper;
import netgest.xwf.core.xwfManager;

/**
 * Ligação ao engine do WorkFlow do XWF
 * @author  Pedro Castro Campos ( pedro.campos@itds.pt )
 * @version 1.0
 */
public class xwfEngineGate implements EngineGate
{
    /**
     * Ligação ao engine do Workflow XWF 
     */
    private xwfManager manager = null;   
    private List errorMessages = new ArrayList();    
  /**
   * Classe construtora que inicia a ligação ao motor do XWF. 
   * @param context Contexto.   
   */       
    public xwfEngineGate(EboContext context) throws boRuntimeException
    {        
        manager = new xwfManager(context,null);
    }
  /**
   * Classe construtora que inicia a ligação ao motor do XWF. 
   * @param context Contexto.
   * @param program <code>xwfProgramRuntime</code> do Contexto.
   */       
    public xwfEngineGate(EboContext context,boObject program) throws boRuntimeException
    {        
        manager = new xwfManager(context,program);
    }
  /**
   * Classe construtora que inicia a ligação ao motor do XWF. 
   * @param boManager <code>xwfBoManager</code>.
   */       
    public xwfEngineGate(xwfBoManager boManager) throws boRuntimeException
    {        
        manager = new xwfManager(boManager);
    }          
  
  /**
   * Inicia um processo do workflow com base na definição de um programa e de uma variável. 
   * @param defProgramBoui boui de definição de um programa.
   * @param variable boui de uma variavel para iniciar o processo, < 0 caso contrário.   
   * @param mode forma de execução do programa.
   * @throws netgest.bo.runtime.boRuntimeException
   */       
    public void startProgramRuntime(long defProgramBoui,long variable, byte mode) throws boRuntimeException
    {
        if(defProgramBoui != 0)
        {  
            if(variable > 0)
            {
                manager.createProgram(defProgramBoui,variable,mode);    
            }
            else
            {
                manager.createProgram(defProgramBoui,mode);
            }
        }        
    }    
  /**
   * Inicia um processo do workflow com base na definição de um programa e de uma lista de variáveis. 
   * @param defProgramBoui boui de definição de um programa.
   * @param variables lista de  variaveis para iniciar o processo, null caso contrário.   
   * @param mode forma de execução do programa.
   * @throws netgest.bo.runtime.boRuntimeException
   */
    public void startProgramRuntime(long defProgramBoui,Hashtable variables, byte mode) throws boRuntimeException
    {                        
        if(defProgramBoui != 0)
        {              
            if(variables == null)
            {
                manager.createProgram(defProgramBoui,mode);    
            }
            else
            {
                manager.createProgram(defProgramBoui,variables,mode);
            }
        }
    }
    /**
     * Devolve o programa a decorrer neste contexto.
     * @return <code>xwfProgramRuntime</code> no engine do xwf. 
     * @throws netgest.bo.runtime.boRuntimeException
     */
    public boObject getProgramRuntime() throws boRuntimeException
    {
        return this.getBoManager().getProgram();
    }       
    /**
     * Devolve o estado em que o workflow se encontra.
     * @return estado em execução.
     */    
    public byte getExecutionMode()
    {
        return getBoManager().getMode();
    }
  /**
   * Devolve um <code>boObject</code> no contexto do workflow. 
   * @param boui identificador do objecto a devolver.
   * @return <code>boObject</code> no contexto do engine.   
   * @throws netgest.bo.runtime.boRuntimeException
   */     
    public boObject getObject(long boui) throws boRuntimeException
    {
        return manager.getBoManager().getObject(boui);
    }
   
 
  /**
   * Termina uma actividade com um valor. 
   * @param activityBoui boui da actividade a alterar.
   * @param value valor da actividade.    
   */      
    public void setActivityValue(long activityBoui, String value) throws boRuntimeException
    {        
        manager.finishedStep(activityBoui,value);   
    }
  /**
   * Devolve a próxima actividade do fluxo de trabalho. 
   * @return boObject próxima actividade do fluxo de trabalho.    
   * @throws netgest.bo.runtime.boRuntimeException
   */          
    public boObject getNextActivity() throws boRuntimeException
    {
        return getNextActivity(null);
    }
  /**
   * Devolve a próxima actividade com base num ramo do fluxo de trabalho. 
   * @param branch ramo do fluxo de trabalho, null caso contrário.
   * @return currentActivity próxima actividade do fluxo de trabalho.    
   */      
    public boObject getNextActivity(String branch) throws boRuntimeException
    {        
        boObject currentActivity = null;
        boolean required = false;
        String aux = null;
        String branchAux = null;
        boObjectList availableActivityList = getAvailableActivityList();
        if(availableActivityList != null)
        {
            availableActivityList.beforeFirst();
            while(availableActivityList.next() && !required) 
            {
                currentActivity = availableActivityList.getObject();
                branchAux = currentActivity.getAttribute("branch").getValueString();
                aux = currentActivity.getAttribute("optional").getValueString();
                if("0".equals(aux))
                {
                    if(branch != null)
                    {
                        if(branch.equals(branchAux))
                        {
                            required = true;    
                        }
                    }
                    else
                    {
                        required = true;   
                    }
                }
            }                      
            if(currentActivity == null && !required)
            {      
                availableActivityList.beforeFirst();
                if(availableActivityList.next())
                {
                    currentActivity = availableActivityList.getObject();  
                }
            }
        }
        return currentActivity;
    }
  /**
   * Devolve a lista de actividades disponíveis para serem executadas. 
   * @return <code>boObjectList</code> lista de actividades do fluxo de trabalho disponíveis.  
   * @throws netgest.bo.runtime.boRuntimeException
   */ 
    private boObjectList getAvailableActivityList() throws boRuntimeException
    {
        StringBuffer boql = new StringBuffer("SELECT xwfActivity WHERE program = " );
        boql.append(manager.getBoManager().getProgBoui());
        boql.append(" AND runningState <= 1 AND ");
        boql.append(xwfHelper.PERFORMER_CLAUSE);
        boql.append(" ORDER BY SYS_DTCREATE,BOUI");
        boObjectList list = manager.getBoManager().listObject(boql.toString(),true,false);
        if(getExecutionMode() == xwfHelper.PROGRAM_EXEC_TEST_MODE)
        {
            list.beforeFirst();
            while(list.next())
            {
                boObject objl = list.getObject();
               if(objl.getAttribute("program").getValueLong() != manager.getBoManager().getProgBoui()
                || (!objl.getStateAttribute("runningState").getValueString().equalsIgnoreCase("open")
                && !objl.getStateAttribute("runningState").getValueString().equalsIgnoreCase("create"))
                )
                   list.removeCurrent(); 
            }
        }
        return list;
//        return manager.getBoManager().listObject(boql.toString(),true,false);        
    } 
  /**
   * Devolve a lista de actividades pendentes para serem executadas, e visiveis para utilizador.
   * @return <code>boObjectList</code> lista de actividades pendentes do workflow.   
   * @throws netgest.bo.runtime.boRuntimeException
   */     
    public boObjectList getPendingActivityList() throws boRuntimeException
    {
        StringBuffer boql = new StringBuffer("SELECT /*NO_SECURITY*/ xwfActivity STATE open OR wait OR reopen WHERE program = ");    
        boql.append(manager.getBoManager().getProgBoui());
        if(!xwfHelper.isWorkFlowAdministrator(this))
        {
            boql.append(" AND ");
            boql.append(xwfHelper.PERFORMER_CLAUSE_ALL);
        }        
        boql.append(" ORDER BY SYS_DTCREATE,BOUI");                
        boObjectList list = manager.getBoManager().listObject(boql.toString(),true,false);
        if(getExecutionMode() == xwfHelper.PROGRAM_EXEC_TEST_MODE)
        {
            list.beforeFirst();
            while(list.next())
            {
                boObject objl = list.getObject();
                if(objl.getAttribute("program").getValueLong() != manager.getBoManager().getProgBoui()
                || (!objl.getStateAttribute("runningState").getValueString().equalsIgnoreCase("open")
                && !objl.getStateAttribute("runningState").getValueString().equalsIgnoreCase("wait"))
                )
                   list.removeCurrent(); 
            }
        }
        return list;
//        return manager.getBoManager().listObject("SELECT xwfActivity STATE open OR wait WHERE program = " + manager.getBoManager().getProgBoui() + " AND "+ xwfHelper.PERFORMER_CLAUSE +" ORDER BY SYS_DTCREATE,BOUI");        
    }
    
  /**
   * Devolve a lista de actividades criadas, e visiveis para utilizador.
   * @return <code>boObjectList</code> lista de actividades criadas do workflow.
   * @throws netgest.bo.runtime.boRuntimeException
   */     
    public boObjectList getCreateActivityList() throws boRuntimeException
    {
        StringBuffer boql = new StringBuffer("SELECT /*NO_SECURITY*/ xwfActivity STATE create WHERE program = ");
        boql.append(manager.getBoManager().getProgBoui());
        if(!xwfHelper.isWorkFlowAdministrator(this))
        {
            boql.append(" AND ");
            boql.append(xwfHelper.PERFORMER_CLAUSE_ALL);
        }        
        boql.append(" ORDER BY SYS_DTCREATE,BOUI");                
        boObjectList list = manager.getBoManager().listObject(boql.toString(),true,false);
        if(getExecutionMode() == xwfHelper.PROGRAM_EXEC_TEST_MODE)
        {
            list.beforeFirst();
            while(list.next())
            {
                boObject objl = list.getObject();
                if(objl.getAttribute("program").getValueLong() != manager.getBoManager().getProgBoui()
                || !objl.getStateAttribute("runningState").getValueString().equalsIgnoreCase("create")
                )
                   list.removeCurrent(); 
            }
        }
        return list;  
//        return manager.getBoManager().listObject("SELECT xwfActivity STATE create WHERE program = " + manager.getBoManager().getProgBoui() + " AND "+ xwfHelper.PERFORMER_CLAUSE +" ORDER BY SYS_DTCREATE,BOUI");        
    }      
  /**
   * Devolve a lista de actividades fechadas, e visiveis para utilizador. 
   * @return <code>boObjectList</code> lista de actividades fechadas do workflow. 
   * @throws netgest.bo.runtime.boRuntimeException
   */      
    public boObjectList getCloseActivityList() throws boRuntimeException
    {        
        StringBuffer boql = new StringBuffer("SELECT /*NO_SECURITY*/ xwfActivity STATE close WHERE program = ");
        boql.append(manager.getBoManager().getProgBoui());
        if(!xwfHelper.isWorkFlowAdministrator(this))
        {
            boql.append(" AND ");
            boql.append(xwfHelper.PERFORMER_CLAUSE_ALL);
        }        
        boql.append(" ORDER BY SYS_DTCREATE,BOUI");                
        boObjectList list = manager.getBoManager().listObject(boql.toString(),true,false);
        if(getExecutionMode() == xwfHelper.PROGRAM_EXEC_TEST_MODE)
        {
            list.beforeFirst();
            while(list.next())
            {
                boObject objl = list.getObject();
                if(objl.getAttribute("program").getValueLong() != manager.getBoManager().getProgBoui()
                || !objl.getStateAttribute("runningState").getValueString().equalsIgnoreCase("close")
                )
                   list.removeCurrent(); 
            }
        }
//        try{
//            Class[] param = {Class.forName("netgest.bo.runtime.boObject"), Class.forName("netgest.bo.runtime.boObject")};  
//            list.orderList(Class.forName("netgest.xwf.common.xwfFunctions").getMethod("conpareActivtiyDates", param));
//        }catch(Exception e){}
        return list;        
//        return manager.getBoManager().listObject("SELECT xwfActivity STATE close WHERE program = " + manager.getBoManager().getProgBoui() + " AND "+ xwfHelper.PERFORMER_CLAUSE +" ORDER BY SYS_DTCREATE,BOUI");
    }     
  /**
   * Devolve o gestor de objectos do workflow XWF. 
   * @return <code>xwfBoManager</code> gestor de objectos.    
   */      
    public xwfBoManager getBoManager()
    {
        return manager.getBoManager();
    }
  /**
   * Devolve o gestor de negócio do workflow XWF. 
   * @return xwfBoManager gestor de negócio.    
   */         
    public xwfManager getManager()
    {
        return manager;
    } 
    /**
     * Adiciona mensagem de erro ao docHtml caso exista, cc guarda internamente.
     * @param message mensagem de erro a adicionar.
     */
    public void addErrorMessage(String message)
    {
        //Foi limpo poara a versão community    
    }
    public List getErrorMessages()
    {                      
        return this.errorMessages;
    }
    /**
     * Remove as mensagem de erro internas     
     */
    public void clearErrorMessages()
    {
        this.errorMessages.clear();
    }
    /**
     * <p>Chama o core do workflow para executar as acções pretendidas.</p>
     * <p>Acções(<code>XwfKeys</code>):</p>
     * <ul>
     *     <li> ACTION_OPEN_KEY
     *     <li> ACTION_CLOSE_KEY
     *     <li> ACTION_CANCEL_KEY
     *     <li> ACTION_SAVE_KEY
     *     <li> ACTION_REOPEN_KEY
     *     <li> ACTION_REMOVE_PROGRAM_KEY
     *     <li> ACTION_CANCEL_PROGRAM_KEY
     *     <li> ACTION_PROCEDURE
     *     <li> ACTION_MOVE_ACTIVITY_KEY
     *     <li> ACTION_REASSIGN_KEY
     *     <li> ACTION_REMOVE_PROGRAM_KEY
     * </ul>     
     * @param action Acção a executar pelo workflow.
     * @param object Objecto sobre o qual recai a acção.
     * @return True se tiver sucesso, False caso contrário.
     * @throws netgest.bo.runtime.boRuntimeException
     */
    public boolean doAction(String action, boObject object) throws boRuntimeException
    {
        return true; //Limpo para a versão community
    }
	@Override
	public void setActivityState(long activityBoui, String state)
			throws boRuntimeException {
	}
}