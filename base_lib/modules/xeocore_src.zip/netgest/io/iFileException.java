package netgest.io;


public class iFileException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -8253172829497246298L;
	
	public iFileException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public iFileException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public iFileException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public iFileException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
