/*Enconding=UTF-8*/
package netgest.io;
import java.io.IOException;
import java.io.InputStream;

import netgest.bo.localizations.MessageLocalizer;
import netgest.bo.runtime.EboContext;

public class iFileWrapper implements iFile {
    private iFile p_ifile;
    private iFileService p_ifileservice;
    public iFileWrapper(iFileService ifs,iFile file) {
        p_ifileservice = ifs;
        p_ifile = file;
    }

    public boolean canRead() {
        return p_ifile.canRead();
    }

    public boolean canWrite() {
        return p_ifile.canWrite();
    }

    public boolean createNewFile() throws IOException,iFilePermissionDenied {
        return p_ifile.createNewFile();
    }

    public boolean delete() throws iFilePermissionDenied {
        return p_ifile.delete();
    }

    public boolean exists() {
        return p_ifile.exists();
    }

    public String getAbsolutePath() {
        return p_ifile.getAbsolutePath();
    }

    public String getName() {
        return p_ifile.getName();
    }

    public String getParent() {
        return p_ifile.getParent();
    }

    public iFile getParentFile() {
        return this.convertToiFileWrapper(p_ifile.getParentFile());
    }

    public String getPath() {
        return p_ifile.getPath();
    }

    public boolean isDirectory() {
        return p_ifile.isDirectory();
    }

    public boolean isFile() {
        return p_ifile.isDirectory();
    }

    public long lastModified() {
        return p_ifile.lastModified();
    }

    public long length() {
        return p_ifile.length();
    }

    public String[] list() throws iFilePermissionDenied {
        return p_ifile.list();
    }

    public String[] list(iFilenameFilter filter) throws iFilePermissionDenied {
        return p_ifile.list(filter);
    }

    public iFile[] listFiles() throws iFilePermissionDenied {
        return this.convertToiFileWrapper(p_ifile.listFiles());
    }

    public iFile[] listFiles(iFileFilter filter) throws iFilePermissionDenied {
        return this.convertToiFileWrapper(p_ifile.listFiles(filter));
    }

    public boolean mkdir() throws iFilePermissionDenied {
        return p_ifile.mkdir();
    }

    public boolean mkdirs() throws iFilePermissionDenied {
        return p_ifile.mkdirs();
    }

    public boolean renameTo(iFile newfile) throws iFilePermissionDenied {
        return p_ifile.renameTo(newfile);
    }

    public boolean setReadOnly() throws iFilePermissionDenied {
        return p_ifile.setReadOnly();
    }

    private iFile[] convertToiFileWrapper(iFile[] ifile) {
        if(ifile == null) return null;
        iFileWrapper[] retif = new iFileWrapper[ifile.length];
        for(int i=0;i<ifile.length;i++) {
            retif[i] = new iFileWrapper(p_ifileservice,ifile[i]);
        }
        return retif;
    }
    private iFile convertToiFileWrapper(iFile ifile) {
        if(ifile == null) return null;
        iFileWrapper retif = new iFileWrapper(p_ifileservice,p_ifile);
        return retif;
    }

    public void setBinaryStream(InputStream is) throws iFilePermissionDenied,
    		iFilePermissionDenied {
    
    	p_ifile.setBinaryStream( is );

    }
    
    public InputStream getInputStream()  throws iFilePermissionDenied {
        return p_ifile.getInputStream();
    }

    public boolean checkIn() throws iFilePermissionDenied {
        return p_ifile.checkIn();
    }

    public boolean checkOut() throws iFilePermissionDenied {
        return p_ifile.checkOut();
    }

    public boolean isCheckedIn() {
        return p_ifile.isCheckedIn();
    }

    public boolean isCheckedOut() {
        return p_ifile.isCheckedOut();
    }
    
    public boolean isVersioned() {
        return p_ifile.isVersioned();
    }

    public boolean makeVersioned() throws iFilePermissionDenied {
      return p_ifile.makeVersioned();
    }
    public String getURI() 
    {
        return p_ifile.getURI();
    }
    
    public void     setDescription(String description) {throw new RuntimeException("setDescription:"+MessageLocalizer.getMessage("NOT_IMPLEMENTED"));}
    public String   getDescription() {throw new RuntimeException("getDescription:"+MessageLocalizer.getMessage("NOT_IMPLEMENTED"));}
    public void     setAuthor(String author) {throw new RuntimeException("setAuthor:"+MessageLocalizer.getMessage("NOT_IMPLEMENTED"));}
    public String   getAuthor() {throw new RuntimeException("getAuthor:"+MessageLocalizer.getMessage("NOT_IMPLEMENTED"));}
    public void     setCategory(String author) {throw new RuntimeException("setCategory:"+MessageLocalizer.getMessage("NOT_IMPLEMENTED"));}
    public String   getCategory() {throw new RuntimeException("getCategory:"+MessageLocalizer.getMessage("NOT_IMPLEMENTED"));}
    
    public long     getKey() {throw new RuntimeException("getKey : "+MessageLocalizer.getMessage("NOT_IMPLEMENTED"));}
    public iFile     getCopy() {throw new RuntimeException("getCopy : "+MessageLocalizer.getMessage("NOT_IMPLEMENTED"));}
    
    public void setVersionUser(String user)
    {
        p_ifile.setVersionUser(user);
    }
    public String getVersionUser()
    {
      return p_ifile.getVersionUser();
    }
    public void setCheckOutUser(String user)
    {
        p_ifile.setCheckOutUser(user);
    }
    public String getCheckOutUser()
    {
      return p_ifile.getCheckOutUser();
    }    
    public long getVersion()
    {
      return p_ifile.getVersion();
    }

 
	@Override
	public boolean close() {
		return false;
	}


	@Override
	public boolean addChild(iFile file) throws iFileException {
		throw new iFileException(MessageLocalizer.getMessage("NOT_IMPLEMENTED"));
	}

	@Override
	public boolean save(EboContext ctx) throws iFileException {
		return false;
	}

	@Override
	public String getId() {
		return null;
	}



	@Override
	public boolean inTransaction() {
		return false;
	}

	@Override
	public void updateFile(iFile newVal) {
	}

	@Override
	public String[] getFileToDeleteOnCommit() {
		return null;
	}

	@Override
	public String[] getFileToDeleteOnRollback() {
		return null;
	}

	@Override
	public void rollback(EboContext ctx) {
	}  
}
