package netgest.bo.xwc.components.connectors;

import netgest.bo.runtime.AttributeHandler;

public interface XEOAttributeProvider {
    
    public AttributeHandler getAttribute( String sAttributeName ); 
    
}
