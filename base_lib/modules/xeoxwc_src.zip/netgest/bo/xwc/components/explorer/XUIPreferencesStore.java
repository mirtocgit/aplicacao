package netgest.bo.xwc.components.explorer;

public interface XUIPreferencesStore extends XUIPropertiesStore {
}
