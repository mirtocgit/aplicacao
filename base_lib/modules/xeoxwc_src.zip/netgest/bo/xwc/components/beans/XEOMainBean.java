package netgest.bo.xwc.components.beans;

@Deprecated
public class XEOMainBean extends netgest.bo.xwc.xeo.beans.XEOMainBean {
}
