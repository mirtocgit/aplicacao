package netgest.bo.xwc.components.model;

import netgest.bo.xwc.framework.components.XUIComponentBase;

public class Columns extends XUIComponentBase {


}
