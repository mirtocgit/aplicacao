package netgest.bo.xwc.components.classic.extjs;

import netgest.bo.xwc.framework.components.XUIComponentBase;

public interface ExtJsRenderer {
	
    public ExtConfig 		getExtJsConfig( XUIComponentBase oComp );

}
