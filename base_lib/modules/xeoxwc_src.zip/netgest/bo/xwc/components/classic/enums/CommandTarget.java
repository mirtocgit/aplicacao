package netgest.bo.xwc.components.classic.enums;

public enum CommandTarget {
	BLANK,
	WINDOW,
	TAB
}
