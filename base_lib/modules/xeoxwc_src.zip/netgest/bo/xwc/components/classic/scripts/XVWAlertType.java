package netgest.bo.xwc.components.classic.scripts;

public enum XVWAlertType {
	ALERT_ICON_INFO,
	ALERT_ICON_ERROR,
	ALERT_ICON_WARNING
}
