package netgest.bo.xwc.framework.jsf;

public class XUIWriterAttributeConst {

    protected String  sTagName; 

    public XUIWriterAttributeConst( String sTagName ) {
        this.sTagName = sTagName;
    }

    public String getValue() {
        return sTagName;
    }

}
