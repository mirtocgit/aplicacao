package netgest.bo.xwc.framework;

@Deprecated
public class XUIComponentPugIn extends XUIComponentPlugIn {

}
