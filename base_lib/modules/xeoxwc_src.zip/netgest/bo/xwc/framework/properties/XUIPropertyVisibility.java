package netgest.bo.xwc.framework.properties;

public enum XUIPropertyVisibility {
	PRIVATE,
	DOCUMENTATION,
	PUBLIC
}
