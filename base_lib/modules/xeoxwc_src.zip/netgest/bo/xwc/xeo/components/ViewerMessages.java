package netgest.bo.xwc.xeo.components;

import netgest.bo.xwc.components.classic.ErrorMessages;

public class ViewerMessages extends ErrorMessages {

	@Override
	public String getRendererType() {
		return "errorMessages";
	}

}
