package netgest.bo.xwc.xeo.localization;

import netgest.bo.xwc.framework.localization.XUILocalizedMessage;

public class X3OCM_Mensagens {
	
	/*
	 * Viewers
	 */	
	
	/* X3OCM_util_lookup.xvw */
	public static final XUILocalizedMessage V_X3OCM_util_lookup_confirm =
			new XUILocalizedMessage( X3OCM_Mensagens.class.getName() , "util_lookup_confirm" );		

	public static final XUILocalizedMessage V_X3OCM_util_lookup_addNew =
		new XUILocalizedMessage( X3OCM_Mensagens.class.getName() , "util_lookup_addNew" );			

	public static final XUILocalizedMessage V_X3OCM_util_lookup_addNew_sPar =
		new XUILocalizedMessage( X3OCM_Mensagens.class.getName() , "util_lookup_addNew_sPar" );
	
	public static final XUILocalizedMessage V_X3OCM_util_lookup_selectedObject =
		new XUILocalizedMessage( X3OCM_Mensagens.class.getName() , "util_lookup_selectedObject" );		

	public static final XUILocalizedMessage V_X3OCM_util_lookup_selectObject =
		new XUILocalizedMessage( X3OCM_Mensagens.class.getName() , "util_lookup_selectObject" );
	
	public static final XUILocalizedMessage V_X3OCM_util_lookup_gridPanelColumn_SYS_CARDID =
		new XUILocalizedMessage( X3OCM_Mensagens.class.getName() , "util_lookup_gridPanelColumn_SYS_CARDID" );
	
	public static final XUILocalizedMessage V_X3OCM_util_lookup_gridPanelColumn_CREATOR =
		new XUILocalizedMessage( X3OCM_Mensagens.class.getName() , "util_lookup_gridPanelColumn_CREATOR" );		

	public static final XUILocalizedMessage V_X3OCM_util_lookup_gridPanelColumn_SYS_DTSAVE =
		new XUILocalizedMessage( X3OCM_Mensagens.class.getName() , "util_lookup_gridPanelColumn_SYS_DTSAVE" );	
}
