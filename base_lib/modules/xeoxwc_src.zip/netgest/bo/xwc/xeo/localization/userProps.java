package netgest.bo.xwc.xeo.localization;

import netgest.bo.xwc.framework.localization.XUILocalizedMessage;

public interface userProps {
	public static final XUILocalizedMessage change=new XUILocalizedMessage( userProps.class.getName(), "change" );
	public static final XUILocalizedMessage languagewarning =new XUILocalizedMessage( userProps.class.getName(), "languagewarning" );
	public static final XUILocalizedMessage profilewarning =new XUILocalizedMessage( userProps.class.getName(), "profilewarning" );
	public static final XUILocalizedMessage changewarning =new XUILocalizedMessage( userProps.class.getName(), "changewarning" );
}
