package netgest.bo.xwc.xeo.beans;
import java.util.EventListener;

public interface XEOEditBeanEventListener extends EventListener {
	
	public void actionPerformed( XEOBeanEventObject event );
	
}
